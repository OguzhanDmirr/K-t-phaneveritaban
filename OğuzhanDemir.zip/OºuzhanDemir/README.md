# LibraryAutomation
The Automation System has been developed in Visual Studio 2019 using the C # programming language. 

![Login2](https://user-images.githubusercontent.com/79140478/110924102-b26ca480-8332-11eb-9331-46f78e4ac3dd.png)
![Main3](https://user-images.githubusercontent.com/79140478/110923846-66216480-8332-11eb-95d8-eb8ca6deebeb.png)
